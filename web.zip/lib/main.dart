import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:apk_installer/apk_installer.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Update App',
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final String versionJsonUrl =
      'https://raw.githubusercontent.com/Kollamohan/Flutter_sampleApp_UpdatePOC/refs/heads/main/version.json';

  @override
  void initState() {
    super.initState();
    checkForUpdate();
  }

  Future<void> checkForUpdate() async {
    await requestStoragePermission();

    try {
      final packageInfo = await PackageInfo.fromPlatform();
      final currentVersion = packageInfo.version;

      final response = await Dio().get(
        versionJsonUrl,
        options: Options(responseType: ResponseType.plain),
      );

      final Map<String, dynamic> jsonData = jsonDecode(response.data);

      final latestVersion = jsonData['version'];
      final apkUrl = jsonData['apk_url'];

      print('Current: $currentVersion — Latest: $latestVersion');

      if (latestVersion != currentVersion) {
        showUpdateDialog(apkUrl);
      }
    } catch (e) {
      print('Error checking update: $e');
    }
  }

  Future<void> requestStoragePermission() async {
    final status = await Permission.storage.request();

    if (!status.isGranted) {
      _showSnackBar('Storage permission denied.');
    }
  }

  void showUpdateDialog(String apkUrl) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Update Available'),
        content: const Text('A new version of the app is available. Do you want to update?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('No'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              downloadAndInstallApk(apkUrl);
            },
            child: const Text('Yes'),
          ),
        ],
      ),
    );
  }

  Future<void> downloadAndInstallApk(String apkUrl) async {
    try {
      final dir = await getExternalStorageDirectory();
      final filePath = '${dir!.path}/update.apk';

      final dio = Dio();
      final response = await dio.download(apkUrl, filePath);

      if (response.statusCode == 200) {
        await ApkInstaller.installApk(filePath: filePath);
      } else {
        _showSnackBar('Failed to download update.');
      }
    } catch (e) {
      _showSnackBar('Install error: $e');
    }
  }

  void _showSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("App Update Checker")),
      body: const Center(child: Text("Welcome mohan! This is the version 1.0.2 old build")),
    );
  }
}