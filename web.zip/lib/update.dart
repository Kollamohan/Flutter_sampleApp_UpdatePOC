/*
import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'package:apk_installer/apk_installer.dart';

class UpdateService {
  // final String versionJsonUrl = 'https://raw.githubusercontent.com/Kollamohan/Flutter_sampleApp_UpdatePOC/main/version.json';

  Future<void> checkForUpdate() async {
    await _requestStoragePermission();

    try {
      final packageInfo = await PackageInfo.fromPlatform();
      final currentVersion = packageInfo.version;

      final response = await Dio().get(
        versionJsonUrl,
        options: Options(responseType: ResponseType.plain), // 👈 force plain text
      );

      // 👇 Explicitly parse the response string as JSON
      final Map<String, dynamic> jsonData = jsonDecode(response.data);

      final latestVersion = jsonData['version'];
      final apkUrl = jsonData['apk_url'];

      print('Current: $currentVersion, Latest: $latestVersion');

      if (latestVersion != currentVersion) {
        _showUpdateDialog(apkUrl);
      }
    } catch (e) {
      print('Error checking update: $e');
    }
  }
  void _showUpdateDialog(BuildContext context, String apkUrl) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Update Available'),
        content: Text('A new version is available. Do you want to update?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('No'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _downloadAndInstallApk(apkUrl, context);
            },
            child: Text('Yes'),
          ),
        ],
      ),
    );
  }

  Future<void> _downloadAndInstallApk(String apkUrl, BuildContext context) async {
    try {
      // Prepare file path
      final dir = await getExternalStorageDirectory();
      final filePath = '${dir!.path}/update.apk';

      // Download the APK
      final dio = Dio();
      final response = await dio.download(apkUrl, filePath);

      if (response.statusCode == 200) {
        // Install the APK
        await ApkInstaller.installApk(filePath: filePath);
      } else {
        _showSnackBar(context, 'Download failed');
      }
    } catch (e) {
      _showSnackBar(context, 'Error: $e');
    }
  }

  void _showSnackBar(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}
*/
